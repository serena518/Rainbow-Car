
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class RainbowCarGame extends JFrame implements KeyListener, Runnable
{
    static int x=90,y=200, score = 0, front=0;
    static RainbowCarGame m = new RainbowCarGame();
                    
    int [][] pos = {{1400, 350}, {1900, 400},{ 2400, 300}};
    boolean defeat = false, defeatScreen = false, started = false;
    static int [][] colors = {{255,0,0},{255,127,0},{255,255,0},{0,255,0},{0,0,255}, {75,0,130}, {148, 0, 211}};
    public RainbowCarGame()
    {
        ColorPanel canvas = new ColorPanel(Color.WHITE);
        Container mainWindow = getContentPane();
        mainWindow.add(canvas);
        
        setSize(600,600);
        setVisible(true);
        addKeyListener(this);
    }
    
    public void keyReleased(KeyEvent e)
    { }
    
    public void keyTyped(KeyEvent e)
    { }
    
    public void keyPressed(KeyEvent e )
    {
        if(!started)
        {
                int c = e.getKeyCode();
                if(c==32)
                {
                    Thread t = new Thread(m);
                    t.start();
                    started = true;
            }
        }
        if(!defeat)
        {
            int c = e.getKeyCode();
            if( c == 38 && y>0)
            y -= 20;
            if( c == 40 && y<620)
            y += 20;
        }
            
        repaint();
        
    }
    
    public void run()
    {
        while(!defeat)
        {
            Random randy = new Random ();
            int [] temp2 = colors[0];
            for(int m = 0; m<colors.length; m++)
            {
                int [] temp;
                if (m==6)
                {
                    colors[m] = temp2;
                }
                else
                {
                    temp = colors[m+1];
                    colors[m] = temp;
                }
            }
            
            if(pos[front][0]+100>70 && pos[front][0]<170)
                {
                    if(y>pos[front][1]-200 && y+70<pos[front][1]) {}
                    else 
                    {
                        defeat=true;
                    }
                }
                
                 for(int m = 0; m<pos.length; m++)
            {
                if(pos[m][0] > -99)
                    pos[m][0] -= 10;
                else
                {
                    pos[m][0]=1400;
                    pos[m][1] = 600-randy.nextInt(300);
                    
                    if(front == 2) front=0;
                    else front++;
                    if(!defeat) score++;
                }
            }
                repaint();
            try
            {
                Thread.sleep(40);
            }
            catch( InterruptedException e )
            {}
            
        }
        while(y<650)
        {
          y+=10;
          repaint();
           try
           {
                Thread.sleep(20);
           }
            catch( InterruptedException e )
           {}
        }
        defeatScreen = true;
        repaint();
        JOptionPane.showMessageDialog(null, "Your score is: " + score + "\n Great job!", "Game Over", JOptionPane.PLAIN_MESSAGE);
    }

    public class ColorPanel extends JPanel
    {
        public ColorPanel(Color backColor)
        {
            setBackground(backColor);
        }
    
    
        public void paintComponent( Graphics g )
        {
            g.setColor(new Color(100,150,200));
            g.fillRect(0,0,5000,1000);
            if(!defeat)
            {
                for(int m = 0; m<colors.length; m++)
            {
                g.setColor(new Color(colors[m][0], colors[m][1], colors[m][2]));
                g.fillRect(0,y+10*m, 100, 10);
            }
        }
            
         
          
            
            g.setColor(new Color(0, 0, 0));
            g.fillRect(pos[0][0],pos[0][1],100,500);
            g.fillRect(pos[1][0],pos[1][1],100,500);
            g.fillRect(pos[2][0],pos[2][1],100,500);
            g.fillRect(pos[0][0],pos[0][1]-700,100,500);
            g.fillRect(pos[1][0],pos[1][1]-700,100,500);
            g.fillRect(pos[2][0],pos[2][1]-700,100,500);
       
            g.setColor(new Color(200,0,0));
            g.fillRect(x,y,60,30);
            g.fillRect(x-20,y+30,100,40);
            g.setColor(new Color(0, 0, 0));
            g.fillOval(x-10, y+50, 30, 30);
            g.fillOval(x+40, y+50, 30, 30);
            if(defeatScreen)
            {
                ImageIcon icon = new ImageIcon("oh noo.png");
                Image i = icon.getImage();
                g.drawImage(i, 0,0, null);
            }
             
            
             
        }
        
    }
    

        public static void main (String args [] )
        {
                JOptionPane.showMessageDialog(null, "Control your car with the up and down keys, avoid the obstacles, and have fun! Press SPACE key to start!", "Start Game", JOptionPane.PLAIN_MESSAGE);
             
        }
    
}

